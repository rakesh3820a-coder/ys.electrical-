# Electrical Guru - Phone APK Build

This bundle lets you build the APK using GitHub Actions from a phone.

1. Create a GitHub repository.
2. Upload `ElectricalGuruAndroidProject.zip` to the repository.
3. Create `.github/workflows/build-apk.yml` and paste the workflow from this bundle.
4. Open Actions -> Build Electrical Guru APK -> Run workflow.
5. When it finishes, open the run -> Artifacts -> `Electrical-Guru-APK` and download the APK.
